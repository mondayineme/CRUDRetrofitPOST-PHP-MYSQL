# CRUDRetrofitPOST
Create, Read, Update &amp; Delete (Retrofit2)

> extract SERVER.zip to your host (htdocs),
> upload users.sql to your database (phpmyadmin)

My Social Media
* instagram : https://www.instagram.com/haerulmuttaqin.id/ 
* facebook : https://www.fb.com/iunkrool/ 

![alt text](https://cdn.rawgit.com/jongracecox/anybadge/master/examples/awesomeness.svg)

